using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallSpawner : MonoBehaviour
{
    public static BallSpawner Instance;


    Queue<Ball> ballsQueue = new Queue<Ball>();
    Queue<Ball> collisionQueue = new Queue<Ball>();
    [SerializeField] int ballsQueueCapacity = 20;
    [SerializeField] bool autoQueueGrow = true;

    [SerializeField] GameObject ballPrefab;
    [SerializeField] Color[] ballColors;
    [SerializeField] float[] sizeBalls;

    [HideInInspector] public int maxBallNumber;
    int maxPower = 12;

    Vector3 defaultSpawnPosition;

    [HideInInspector]
    public List<GameObject> Children;

    int _minValue;
    int currentMinValue;
    private void Awake()
    {
        Instance = this;
        defaultSpawnPosition = transform.position;
        maxBallNumber = (int)Mathf.Pow(2, maxPower);
        InitializeBallsQueue();
        currentMinValue = 1;
    }

    void InitializeBallsQueue()
    {
        for (int i = 0; i < ballsQueueCapacity; i++)
        {
            AddBallToQueue();
            AddBallCollisionToQueue();
        }
    }

    void AddBallToQueue()
    {
        Ball ball = Instantiate(ballPrefab, defaultSpawnPosition, Quaternion.identity, transform).GetComponent<Ball>();

        ball.gameObject.SetActive(false);
        ball.IsMainBall = false;
        ballsQueue.Enqueue(ball);
    }

    void AddBallCollisionToQueue()
    {
        Ball ball = Instantiate(ballPrefab, defaultSpawnPosition, Quaternion.identity, transform).GetComponent<Ball>();

        ball.gameObject.SetActive(false);
        ball.IsMainBall = false;
        ball.IsQueueCollision = true;
        collisionQueue.Enqueue(ball);
    }

    public Ball Spawn(int _num, Vector3 _pos)
    {
        if(ballsQueue.Count == 0)
        {
            if (autoQueueGrow)
            {
                ballsQueueCapacity++;
                AddBallToQueue();
            }
            else
            {
                Debug.LogError("Err");
                return null;
            }
        }
        Ball ball = ballsQueue.Dequeue();
        ball.transform.position = _pos;
        ball.SetNumber(_num);
        ball.SetColor(GetColor(_num));
        ball.SetSize(GetSize(_num));
        ball.gameObject.SetActive(true);

        return ball;
    }

    public Ball SpawnCollision(int _num, Vector3 _pos)
    {
        if (collisionQueue.Count == 0)
        {
            if (autoQueueGrow)
            {
                ballsQueueCapacity++;
                AddBallCollisionToQueue();
            }
            else
            {
                Debug.LogError("Err");
                return null;
            }
        }
        Ball ball = collisionQueue.Dequeue();
        ball.transform.position = _pos;
        ball.SetNumber(_num);
        ball.SetColor(GetColor(_num));
        ball.SetSize(GetSize(_num));
        ball.gameObject.SetActive(true);

        return ball;
    }

    public Ball SpawnRandom()
    {
        _minValue = (int)GameManager.Instance.Level_Stage / 2;
        return Spawn(GenarateRandomNumber(_minValue), defaultSpawnPosition);
    }

    public void DesTroyBall(Ball _ball)
    {
        _ball.BallRb.velocity = Vector3.zero;
        _ball.BallRb.angularVelocity = Vector3.zero;
        _ball.transform.rotation = Quaternion.identity;
        _ball.IsMainBall = false;
        _ball.gameObject.SetActive(false);

        if (_ball.IsQueueCollision)
            collisionQueue.Enqueue(_ball);
        else
            ballsQueue.Enqueue(_ball);
    }
    public int GenarateRandomNumber(int _minValue)
    {
        int minValue = _minValue;
        int maxValue = minValue + 5;
        if (minValue < 1)
        {
            minValue = 1;
            maxValue = 5;
        }
        int r = Random.Range(minValue, maxValue);
        return (int)Mathf.Pow(2, r);
    }

    private Color GetColor(int _num)
    {
        int value = (int)(Mathf.Log(_num) / Mathf.Log(2));
        if (value > 12)
        {
            value = value % 12;
        }
        return ballColors[value - 1];
    }

    private float GetSize(int _num)
    {
        int valueArray = _minValue;
        int a = (int)(Mathf.Log(_num) / Mathf.Log(2));
        Debug.Log("a " + a + " min value " + _minValue + " num " + _num);
        if (valueArray < 1) 
            valueArray = 1;
        return sizeBalls[a - valueArray];
    }

    public void GetAllBall()
    {
        Children.Clear();
        foreach (Transform child in transform)
        {
            if (child.gameObject.activeInHierarchy && !child.GetComponent<Ball>().IsMainBall)
            {
                Children.Add(child.gameObject);
            }
        }
    }

    public void CheckDestroyBallSmall()
    {
        _minValue = (int)GameManager.Instance.Level_Stage / 2;
        if (currentMinValue < _minValue)
        {
            //Destroy balls small
            GetAllBall();
            for (int i = 0; i < Children.Count; i++)
            {
                if (Children[i].GetComponent<Ball>().BallNumber <= (int)Mathf.Pow(2, currentMinValue))
                    Destroy(Children[i]);
            }
            currentMinValue = _minValue;

            ballsQueue.Clear();
            InitializeBallsQueue();
        }
    }

    public Ball SetBallCollision(Ball newBall, int _num, Vector3 _pos)
    {
        newBall.transform.position = _pos;
        newBall.SetNumber(_num);
        newBall.SetColor(GetColor(_num));
        newBall.SetSize(GetSize(_num));

        return newBall;
    }

    // Tool DEV
    public Ball SpawnToolBall(int valueBall)
    {
        _minValue = valueBall;
        return Spawn(GenarateToolBall(_minValue), new Vector3(defaultSpawnPosition.x + 1.3f, defaultSpawnPosition.y, defaultSpawnPosition.z));
    }
    public int GenarateToolBall(int _minValue)
    {
        return (int)Mathf.Pow(2, _minValue);
    }

    //public void GetBallArray()
    //{
    //    Transform[] allBall = transform.GetComponentsInChildren<Transform>();
    //    for (int i = 0; i < allBall.Length; i++)
    //    {
    //        int a = allBall[i].GetComponent<Ball>().BallNumber;
    //    }  
    //}
}
