using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallCollision : MonoBehaviour
{
    Ball ball;
    float pushForce = 2.5f;
    List<Ball> ballOther = new List<Ball>();
    [HideInInspector]
    public bool GemImpact;
    private void Awake()
    {
        ball = GetComponent<Ball>();
    }
    
    private void OnCollisionEnter(Collision collision) // check 2 ball big duoc tao cung luc 
    {
        Ball otherBall = collision.gameObject.GetComponent<Ball>();

        if (GemImpact && collision != null)
        {
            GemImpact = false;
            if(otherBall)
                AudioManager.Instance.GemImpactSound();
        }

        if (otherBall != null && ball.BallID > otherBall.BallID)
        {
            if (ball.BallNumber == otherBall.BallNumber)
            {
                Collider c = collision.GetContact(0).otherCollider;
                Ball ob = c.gameObject.GetComponent<Ball>();
                Vector3 contactPoint = collision.contacts[0].point;
                if (!GameManager.Instance.CheckDelayExplosion)
                {
                    StartCoroutine(DelayExplosion(contactPoint, ob, 0));
                }
                else
                {
                    StartCoroutine(DelayExplosion(contactPoint, ob, 0.18f));
                }
            }
        }
    }

    IEnumerator DelayExplosion(Vector3 contactPoint, Ball otherBall, float time)
    {
        GameManager.Instance.CheckDelayExplosion = true;
        CameraShake.instance.shouldShake = true;
        yield return new WaitForSeconds(time);
        Ball newBall = BallSpawner.Instance.SpawnCollision(ball.BallNumber * 2, contactPoint);
        newBall.BallRb.isKinematic = false;
        newBall.BallRb.AddForce(new Vector3(0, 1f, 0) * pushForce, ForceMode.Impulse);
        GameManager.Instance.UpdateCurrentExp(newBall.BallNumber);
        ball.parentTxt.transform.parent = ball.transform;
        ball.parentTxt.transform.localRotation = Quaternion.identity;
        otherBall.parentTxt.transform.parent = otherBall.transform;
        otherBall.parentTxt.transform.localRotation = Quaternion.identity;

        #region Explosion & Sound
        GameManager.Instance.explosion.transform.position = new Vector3(contactPoint.x, contactPoint.y, -1f);
        GameManager.Instance.explosion.Play();

        AudioManager.Instance.ComboSound(GameManager.soudPos);
        if (GameManager.soudPos < AudioManager.Instance.combos.Length - 1)
            GameManager.soudPos++;

        //Collider[] surroundedBalls = Physics.OverlapSphere(contactPoint, 1.2f);
        //float explosionForce = 400f;
        //float explosionRadius = 1.5f;
        //foreach (Collider item in surroundedBalls)
        //{
        //    if (item.attachedRigidbody != null)
        //        item.attachedRigidbody.AddExplosionForce(explosionForce, contactPoint, explosionRadius);
        //}
        #endregion

        BallSpawner.Instance.DesTroyBall(ball);
        BallSpawner.Instance.DesTroyBall(otherBall);
        CameraShake.instance.shouldShake = false;

        #region Next Stage
        if (newBall.BallNumber >= GameManager.Instance.BallLevel)
        {
            Debug.Log(newBall.BallNumber + "WIN" + GameManager.Instance.Level_Stage);
            Destroy(newBall.gameObject);
            GameManager.Instance.NextStage();
            AudioManager.Instance.PlaySoudManager(1);
        }
        #endregion
    }
}
